/*
 * =====================================================================================
 *
 *       Filename:  wheel.cpp
 *
 *    Description:  
 *
 *
 *        Version:  1.0
 *        Created:  04/29/16 17:03:48
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Shangmc 
 *        Company:  
 *
 * =====================================================================================
 */
#include "ros/ros.h"
#include "std_msgs/String.h"
#include <sstream>
#include <pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <fcntl.h>
#include <termios.h>
#include <stdio.h>
#include <stdlib.h>
#include"mraa.h"
#include<pthread.h>
#include<std_msgs/Float32.h>
#include<unistd.h>
float left=0;
float right=0;
float sumleft=0;
float sumright=0;
int chang_flag=0;
int change=0;
char buff[18]={0x00};
pthread_mutex_t mutex;
pthread_cond_t cond;
pthread_mutex_t mutex1;
pthread_cond_t cond1;
void chartofloat (char *str)
{
	int inter;
	float dec;
inter=((str[1]-48)*10.0+str[2]-48);
dec=((str[3]-48)/10.0+(str[4]-48)/100.0+(str[5]-48)/1000.0+(str[6]-48)/10000.0+(str[7]-48)/100000.0+(str[8]-48)/1000000.0);
left=inter+dec;
inter=((str[10]-48)*10.0+str[11]-48);
dec=((str[12]-48)/10.0+(str[13]-48)/100.0+(str[14]-48)/1000.0+(str[15]-48)/10000.0+(str[16]-48)/100000.0+(str[17]-48)/1000000.0);
right=inter+dec;
}
void encoder()
{
	int j=0;
	mraa_uart_context uart;
	uart = mraa_uart_init_raw("/dev/ttyS2");
	mraa_uart_set_baudrate(uart,115200);
	mraa_uart_set_mode(uart,8,MRAA_UART_PARITY_NONE,1);
	ros::NodeHandle n;
	ros::Rate loop_r(20);
	while(ros::ok())
	{
		pthread_mutex_lock(&mutex1);
		while(change!=1)
		pthread_cond_wait(&cond1,&mutex1);
        change=0;
		pthread_mutex_unlock(&mutex1);
		pthread_mutex_lock(&mutex);
        sumleft=0.0;
        sumright=0.0;
for(j=0;j<2;j++)
{
	    mraa_uart_read(uart,buff,18);
//		printf("%s\n",buff);
		chartofloat(buff);
        sumleft+=left;
        sumright+=right;
        loop_r.sleep();
	}
sumleft=sumleft/2.0;
sumright=sumright/2.0;
chang_flag=1;
pthread_mutex_unlock(&mutex);
pthread_cond_signal(&cond);
}
}

int main(int argc,char **argv)
{
	std::string serial_port;
	int serial_baudrate=115200;
	std::string frame_id;
	pthread_t tid;
	pthread_mutex_init(&mutex,NULL);
	pthread_mutex_init(&mutex1,NULL);
	pthread_cond_init(&cond1,NULL);
	pthread_cond_init(&cond,NULL);
	pthread_create(&tid,NULL,(void*(*)(void*))encoder,NULL);
	ros::init(argc,argv,"wheel");
	ros::NodeHandle nh;
	ros::Publisher leftwheel=nh.advertise<std_msgs::Float32>("leftspeed",1000);
	ros::Publisher rightwheel=nh.advertise<std_msgs::Float32>("rightspeed",1000);
	ros::NodeHandle nh_private("~");
	nh_private.param<std::string>("serial_port",serial_port,"/dev/ttyS2");
	nh_private.param<int>("serial_baudrate",serial_baudrate,115200);
	nh_private.param<std::string>("frame_id",frame_id,"encoder");
	ros::Rate loop_rate(10);
	std_msgs::Float32 left1;
	std_msgs::Float32 right1;
	while(ros::ok())
	{
		pthread_mutex_lock(&mutex1);
		change=1;
		pthread_cond_signal(&cond1);
        pthread_mutex_unlock(&mutex1);
		pthread_mutex_lock(&mutex);
		while(chang_flag!=1)
		{
			pthread_cond_wait(&cond,&mutex);
		}

left1.data=sumleft;
//printf("%f\n",sumleft);
right1.data=sumright;
chang_flag=0;
pthread_mutex_unlock(&mutex);
leftwheel.publish(left1);
rightwheel.publish(right1);
ros::spinOnce();
loop_rate.sleep();
	}
pthread_mutex_destroy(&mutex);
pthread_cond_destroy(&cond);
pthread_mutex_destroy(&mutex1);
pthread_cond_destroy(&cond1);
return 0;
}

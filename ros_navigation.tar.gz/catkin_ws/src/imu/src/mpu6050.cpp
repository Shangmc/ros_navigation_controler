/*
 * =====================================================================================
 *
 *       Filename:  mpu6050.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  01/16/16 00:36:02
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Shamgmc
 *        Company:  
 *
 * =====================================================================================
 */
#include<ros/ros.h>
#include<stdlib.h>
#include<stdio.h>
#include<std_msgs/Float32.h>
#include<std_msgs/String.h>
#include<mraa.h>
#include<pthread.h>
#include<unistd.h>
#include<sstream>
float yawdata=0;
float pitchdata=0;
float rolldata=0;
char buf[30];
int result=0;
int result_flag=0;
pthread_mutex_t mutexyaw;
pthread_mutex_t mutexyaw1;
pthread_cond_t  condyaw;
pthread_cond_t  condyaw1;

float charfloat(char *str)
{
	int inter;
	float dec;
	inter=((str[1]-48)*100.0+(str[2]-48)*10.0+str[3]-48);
	dec=((str[4]-48)/10.0+(str[5]-48)/100.0+(str[6]-48)/1000.0+(str[7]-48)/10000.0+(str[8]-48)/100000.0+(str[9]-48)/1000000.0);
	if(str[0]=='-')
		return (0-inter+dec);
	if(str[0]=='+')
		return (inter+dec);

}
void ypr(char *c)
{
int j;
int i;
char strr[10]={0x00};
char strp[10]={0x00};
mraa_uart_context tty;
tty=mraa_uart_init_raw("/dev/ttyS5");
mraa_uart_set_baudrate(tty,115200);
mraa_uart_set_mode(tty,8,MRAA_UART_PARITY_NONE,1);
ros::NodeHandle nhn;
ros::Rate loop_rp(10);
while(ros::ok())
{
	pthread_mutex_lock(&mutexyaw1);
	while(result!=1)
	pthread_cond_wait(&condyaw1,&mutexyaw1);
	result=0;
	pthread_mutex_unlock(&mutexyaw1);
	pthread_mutex_lock(&mutexyaw);
	yawdata=0;
	rolldata=0;
	pitchdata=0;


	mraa_uart_read(tty,buf,30);
for(i=0;i<10;i++)
{
	strp[i]=buf[i+10];
    strr[i]=buf[i+20];
}
yawdata=charfloat(buf);
pitchdata=charfloat(strp);
rolldata=charfloat(strr);
result_flag=1;
pthread_mutex_unlock(&mutexyaw);
pthread_cond_signal(&condyaw);
//loop_rp.sleep();
}
}
int main(int argc,char **argv)
{
	std::string serial_port;
	int serial_baudrate=115200;
	std::string frame_id;
	pthread_t tid;
	pthread_mutex_init(&mutexyaw,NULL);
	pthread_mutex_init(&mutexyaw1,NULL);
	pthread_cond_init(&condyaw1,NULL);
	pthread_cond_init(&condyaw,NULL);
	pthread_create(&tid,NULL,(void*(*)(void*))ypr,NULL);
   ros::init(argc,argv,"mpu6050");
   ros::NodeHandle nnn;
   //ros::NodeHandle n1;
   //ros::NodeHandle n2;
   ros::Publisher yaw=nnn.advertise<std_msgs::Float32>("yaw",100);
   ros::Publisher pitch=nnn.advertise<std_msgs::Float32>("pitch",100);
   ros::Publisher roll=nnn.advertise<std_msgs::Float32>("roll",100);
   ros::NodeHandle nnn_private("~");
	   nnn_private.param<std::string>("serial_port", serial_port, "/dev/ttyS5");
   nnn_private.param<int>("serial_baudrate",serial_baudrate,115200);
   nnn_private.param<std::string>("frame_id",frame_id,"imu");
   ros::Rate loop_rate(10);
   std_msgs::Float32 yaw1;
   std_msgs::Float32 pitch1;
   std_msgs::Float32 roll1;
while(ros::ok())
{
	pthread_mutex_lock(&mutexyaw1);
	result=1;
	pthread_cond_signal(&condyaw1);
	pthread_mutex_unlock(&mutexyaw1);
	pthread_mutex_lock(&mutexyaw);
	while(result_flag!=1)
		pthread_cond_wait(&condyaw,&mutexyaw);
	yaw1.data=yawdata;
	pitch1.data=pitchdata;
	roll1.data=rolldata;
	result_flag=0;
	yaw.publish(yaw1);
	pitch.publish(pitch1);
	roll.publish(roll1);
pthread_mutex_unlock(&mutexyaw);
/*  yaw.publish(yaw1);
pitch.publish(pitch1);
roll.publish(roll1);*/
ros::spinOnce();
loop_rate.sleep();
}
pthread_mutex_destroy(&mutexyaw);
pthread_mutex_destroy(&mutexyaw1);
pthread_cond_destroy(&condyaw);
pthread_cond_destroy(&condyaw1);
return 0;
}

/*
 * =====================================================================================
 *
 *       Filename:  base_controller.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  01/15/16 20:58:39
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Shangmc 
 *        Company:  
 *
 * =====================================================================================
 */
#include<ros/ros.h>
#include<stdlib.h>
#include<stdio.h>
#include<std_msgs/Float32.h>
#include<std_msgs/String.h>
#include<boost/thread.hpp>
#include<boost/thread/mutex.hpp>
#include<boost/thread/condition.hpp>
#include<iostream>
#include<nav_msgs/Odometry.h>
#include<string.h>
#include"mraa.h"
#include<unistd.h>
int change=0;
int change_flag=0;
float vx=0;
float angularz=0;
boost::mutex mutexmaster;
boost::mutex mutexslave;
boost::condition condmaster;
boost::condition condslave;
boost::mutex data;
void callback(const geometry_msgs::Twist &msg)
{
	{
	boost::mutex::scoped_lock lock(mutexmaster);
	while(change!=1)
		condmaster.wait(lock);
	}
	change=0;
	boost::mutex::scoped_lock lock(data);

	vx=msg.linear.x;
	angularz=msg.angular.z;
	ROS_INFO("vx and angular is %f %f\n",vx,angularz);
	change_flag=1;
   condslave.notify_all();
}
int main(int argc,char **argv)
{
	uint8_t command[3]={0x00};
	uint8_t initilize[3]={'S',0x00,0x00};
    uint8_t *recv;
    float vxlast=0;
	float leftvel=0;
	float rightvel=0;
	float l=0.561;
	ros::init(argc,argv,"move_basecontroller");
	ros::NodeHandle n;
	ros::Subscriber base=n.subscribe("cmd_vel",100,callback);
    mraa_init();
	mraa_spi_context spi;
	spi=mraa_spi_init_raw(1,0);
if(spi)
	ROS_INFO("success to setup\n");
mraa_spi_mode(spi,MRAA_SPI_MODE0);
mraa_spi_transfer_buf(spi,initilize,recv,3);
mraa_spi_transfer_buf(spi,initilize,recv,3);
ros::AsyncSpinner state(2);
state.start();
ros::Rate loop_rate(3.3);
while(ros::ok())
{
	{
	boost::mutex::scoped_lock lock(mutexmaster);
	change=1;
	condmaster.notify_all();
	}
	{
		boost::mutex::scoped_lock lock(mutexslave);
		while(change_flag!=1)
			condslave.wait(lock);

	}
	boost::mutex::scoped_lock lock(data);
	change_flag=0;
	if(vx==0&&angularz==0)
	{
		mraa_spi_transfer_buf(spi,initilize,recv,3);
//	  printf("hello1\n");
	}
	if(vx==0)
	{
	 if(angularz>0)
	{
		leftvel=(-1)*angularz*l/2;
		rightvel=angularz*l/2;
      command[0]='L';
	  command[1]=0x50;
	  command[2]='E';
	  mraa_spi_transfer_buf(spi,command,recv,3);
//	  printf("hello2\n");
	}
	 if(angularz<0)
	{
		leftvel=angularz*l/2;
		rightvel=(-1)*angularz*l/2;
		command[0]='R';
		command[1]=0x50;
		command[2]='E';
		mraa_spi_transfer_buf(spi,command,recv,3);
//		printf("hello3\n");
	}
	}
	if(angularz==0)
	{
if(vx>vxlast)
{
	leftvel=rightvel=vx;
	command[0]='A';
	command[1]=0x35;
	command[2]='E';
	mraa_spi_transfer_buf(spi,command,recv,3);
//	printf("hello4\n");
}
else
{
	leftvel=rightvel=vx;
	command[0]='A';
	command[1]=0x20;
	command[2]='E';
	mraa_spi_transfer_buf(spi,command,recv,3);
//	printf("hello5\n");
}
}
if(vx<0)
{
	command[0]='B';
	command[1]=0x20;
	command[3]='E';
	mraa_spi_transfer_buf(spi,command,recv,3);
//	printf("hello6\n");
}
vxlast=vx;
loop_rate.sleep();
}
return 0;
}




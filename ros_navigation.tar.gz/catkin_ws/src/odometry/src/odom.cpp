/*
 * =====================================================================================
 *
 *       Filename:  odom.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  05/09/16 15:36:55
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author: Shangmc
 *        Company:  
 *
 * =====================================================================================
 */
#include<ros/ros.h>
#include<tf/transform_broadcaster.h>
#include<stdlib.h>
#include<nav_msgs/Odometry.h>
#include<stdio.h>
#include<std_msgs/String.h>
#include<std_msgs/Float32.h>
#include<boost/thread/thread.hpp>
//#include<boost/xtime.hpp>
#include<boost/thread/mutex.hpp>
#include<boost/thread/condition.hpp>
#include<iostream>
int changeleft=0;
int changeright=0;
int changeyaw=0;
int changepitch=0;
int changeroll=0;
int changemaster=0;
boost::mutex mutexyaw;
boost::condition condmaster;
boost::condition condslave;
boost::mutex mutexpitch;
boost::mutex mutexroll;
boost::mutex mutexright;
boost::mutex mutexleft;
boost::mutex shareleft;
boost::mutex shareright;
boost::mutex shareyaw;
boost::mutex sharepitch;
boost::mutex shareroll;
boost::mutex sharemaster;
boost::mutex share;
boost::mutex data;
float x=0;
float y=0;
float vx=0;
float vy=0;
float vth=0;
float yawvelocity=0;
float pitchvelocity=0;
float rollvelocity=0;
float i=0;
float leftvelocity=0;
float rightvelocity=0;
class subscribtion
{
	public:
		void leftspeedvelocity(const std_msgs::Float32::ConstPtr& msg)
		{
			{
			boost::mutex::scoped_lock lock(shareleft);
            while(changeleft!=1)
				condmaster.wait(lock);
			}
			changeleft=0;
           boost::mutex::scoped_lock lock(mutexleft);
		    leftvelocity=msg->data;
		}
		void rightspeedvelocity(const std_msgs::Float32::ConstPtr& msg)
		{
			{
				boost::mutex::scoped_lock lock(shareright);
				while(changeright!=1)
					condmaster.wait(lock);
			}
           changeright=0;
		   boost::mutex::scoped_lock lock(mutexright);
		   rightvelocity=msg->data;
		}
		void yaw(const std_msgs::Float32::ConstPtr& msg)
		{
			{
				boost::mutex::scoped_lock lock(shareyaw);
				while(changeyaw!=1)
					condmaster.wait(lock);
			}
			changeyaw=0;
			boost::mutex::scoped_lock lock(mutexyaw);
			yawvelocity=msg->data;
			changemaster=1;
			condslave.notify_all();
		}
		void pitch (const std_msgs::Float32::ConstPtr& msg)
		{
			{
				boost::mutex::scoped_lock lock(sharepitch);
				while(changepitch!=1)
					condmaster.wait(lock);
			}
			changepitch=0;
            boost::mutex::scoped_lock lock(mutexpitch);
			pitchvelocity=msg->data;
		}
		void roll(const std_msgs::Float32::ConstPtr& msg)
		{
			{
				boost::mutex::scoped_lock lock(shareroll);
				while(changeroll!=1)
					condmaster.wait(lock);
			}
			changeroll=0;
			boost::mutex::scoped_lock lock(mutexroll);
			rollvelocity=msg->data;
		}

};
int main(int argc,char **argv)
{
	float dt=0;
	float dx;
	float dy;
	float yawlast=0.0;
	float vth;
	float dyaw=0.0;
	int k=0;//adjust the first data;
	ros::init(argc,argv,"odomsubscribe");
	ros::NodeHandle n;
	ros::NodeHandle nh;
	subscribtion nhn;
	ros::Publisher odom_pub=nh.advertise<nav_msgs::Odometry>("odom",100);
	tf::TransformBroadcaster odom_broadcaster;
	geometry_msgs::TransformStamped odom_trans;
	odom_trans.header.frame_id="odom";
	odom_trans.child_frame_id="base_link";
	ros::Time current_time;
	ros::Time last_time;
	current_time=ros::Time::now();
	last_time=ros::Time::now();
	ros::Subscriber subleft=n.subscribe("leftspeed",100,&subscribtion::leftspeedvelocity,&nhn);
	ros::Subscriber subright=n.subscribe("rightspeed",100,&subscribtion::rightspeedvelocity,&nhn);
	ros::Subscriber subyaw=n.subscribe("yaw",100,&subscribtion::yaw,&nhn);
	ros::Subscriber subpitch=n.subscribe("pitch",100,&subscribtion::pitch,&nhn);
	ros::Subscriber subroll=n.subscribe("roll",100,&subscribtion::roll,&nhn);
	ros::AsyncSpinner state(5);
	state.start();
	ros::Rate r(33.3);
	while(ros::ok())
	{


		boost::mutex::scoped_lock lock(sharemaster);
		changeleft=1;
		changeright=1;
		changeyaw=1;
		changeroll=1;
		changepitch=1;
		condmaster.notify_all();

		{
			boost::mutex::scoped_lock lock(share);
			while(changemaster!=1)
				condslave.wait(lock);
			changemaster=0;
		}
	//	boost::mutex::scoped_lock lock(data);
        // printf("yaw is %f\n",yawvelocity);
		/*====compute velocity wheel===*/
	 		vx=0.5*(leftvelocity+rightvelocity)/0.303;
		current_time=ros::Time::now();
		dt=(current_time-last_time).toSec();
		printf("yaw is %f\n",yawlast);
	/*  	if(yawlast==0)
		{
		yawvelocity=0.0;//except the first data
		dx=cos(yawvelocity-yawlast)*vx*dt;
		dy=sin(yawvelocity-yawlast)*vx*dt;
		}
		else
		{
			dx=cos(yawvelocity-yawlast)*vx*dt;
			dy=sin(yawvelocity-yawlast)*vx*dt;
		}*/
		dyaw=yawvelocity-yawlast;
		if(dyaw>100)
		{
			
			dx=cos(yawlast)*vx*dt;
			dy=sin(yawlast)*vx*dt;
			printf("destroyed data is %f\n",dyaw);
		}
		else
		{
		dx=cos(yawlast)*vx*dt;
		dy=sin(yawlast)*vx*dt;
		printf("data is %f\n",dyaw);
		}
		x+=dx;
		y+=dy;
		vth=(dyaw)/dt;//angular velocity
		yawlast=yawvelocity;
	//	printf("yaw is %f\n",yawlast);
		geometry_msgs::Quaternion odom_quat = tf::createQuaternionMsgFromRollPitchYaw(rollvelocity,pitchvelocity,yawvelocity);
		nav_msgs::Odometry odom;
		odom_trans.header.stamp = current_time;
		odom_trans.transform.translation.x=x;
		odom_trans.transform.translation.y=y;
		odom_trans.transform.translation.z=0.0;
		odom_trans.transform.rotation = odom_quat;
		odom.header.stamp=current_time;
		odom.header.frame_id="odom";
		odom.child_frame_id="base_link";
		odom.pose.pose.position.x=x;
		odom.pose.pose.position.y=y;
		odom.pose.pose.position.z=0.0;
		odom.pose.pose.orientation=odom_quat;
		odom.twist.twist.linear.x=vx;
		odom.twist.twist.linear.y=vy;
		odom.twist.twist.linear.z=0.0;
		odom.twist.twist.angular.z=vth;

		odom_broadcaster.sendTransform(odom_trans);
			//printf("succees to sendTransform\n");
		odom_pub.publish(odom);
	//	condmaster.notify_all();
	//	printf("yaw is %f\n",yawlast);
	//	}
	last_time=current_time;
		r.sleep();
	}
return 0;
}
